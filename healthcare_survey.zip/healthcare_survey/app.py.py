from flask import Flask, render_template, request, redirect, url_for, flash
from pymongo import MongoClient
import os
from os import environ
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your-secret-key-12345'

# MongoDB Connection
# prefer MONGO_URI from environment, fallback to localhost
MONGO_URI = environ.get("MONGO_URI", "mongodb://localhost:27017/")
try:
    client = MongoClient(MONGO_URI)
    db = client.healthcare_survey
    users_collection = db.users
    print("✅ Connected to MongoDB")
except Exception as e:
    print(f"❌ MongoDB connection failed: {e}")
    users_collection = None

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit_survey():
    try:
        # Get form data
        age = int(request.form['age'])
        gender = request.form['gender']
        total_income = float(request.form['total_income'])
        
        # Get expenses
        expenses = {
            'utilities': float(request.form.get('utilities', 0)),
            'entertainment': float(request.form.get('entertainment', 0)),
            'school_fees': float(request.form.get('school_fees', 0)),
            'shopping': float(request.form.get('shopping', 0)),
            'healthcare': float(request.form.get('healthcare', 0))
        }
        
        # Create user data
        user_data = {
            'age': age,
            'gender': gender,
            'total_income': total_income,
            'expenses': expenses,
            'timestamp': datetime.now()
        }
        
        # Store in MongoDB
        if users_collection is not None:
            users_collection.insert_one(user_data)
            print("✅ Data saved to MongoDB!")
        else:
            print("✅ Data processed (MongoDB not available)")
        
        flash('Thank you! Your survey has been submitted successfully.', 'success')
        return redirect(url_for('home'))
        
    except Exception as e:
        flash(f'Error: {str(e)}', 'error')
        return redirect(url_for('home'))

# Add a route to view collected data
@app.route('/data')
def view_data():
    if users_collection is not None:
        users = list(users_collection.find())
        return f"Total users in database: {len(users)}"
    else:
        return "MongoDB not connected"

if __name__ == '__main__':
    app.run(debug=True, port=5000)

    # expose WSGI callable expected by Gunicorn/Elastic Beanstalk
    application = app

if __name__ == "__main__":
    port = int(environ.get("PORT", 5000))
    debug = environ.get("FLASK_DEBUG", "0") == "1"
    app.run(host="0.0.0.0", port=port, debug=debug)