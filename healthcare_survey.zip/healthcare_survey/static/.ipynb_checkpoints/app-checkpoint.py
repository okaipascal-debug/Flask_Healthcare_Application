from flask import Flask, render_template, request, redirect, url_for, flash
import os
from datetime import datetime

# Create Flask app
app = Flask(__name__)
app.secret_key = '12345'

# We'll add MongoDB later - for now we'll use a simple list to test
users_data = []

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit_survey():
    try:
        # Get data from form
        age = int(request.form['age'])
        gender = request.form['gender']
        total_income = float(request.form['total_income'])
        
        # Get expenses - handle cases where checkboxes aren't checked
        expenses = {
            'utilities': float(request.form.get('utilities', 0)),
            'entertainment': float(request.form.get('entertainment', 0)),
            'school_fees': float(request.form.get('school_fees', 0)),
            'shopping': float(request.form.get('shopping', 0)),
            'healthcare': float(request.form.get('healthcare', 0))
        }
        
        # Create user data dictionary
        user_data = {
            'age': age,
            'gender': gender,
            'total_income': total_income,
            'expenses': expenses,
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        # Store in our temporary list (we'll replace with MongoDB later)
        users_data.append(user_data)
        print(f"User data stored: {user_data}")  # This shows in your terminal
        
        flash('Thank you! Your survey has been submitted successfully.', 'success')
        return redirect(url_for('home'))
        
    except Exception as e:
        flash(f'Error: {str(e)}', 'error')
        return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)