class User:
    """Class to represent user data from our survey"""
    
    def __init__(self, age, gender, total_income, expenses):
        self.age = age
        self.gender = gender
        self.total_income = total_income
        self.expenses = expenses  # This is a dictionary
    
    def calculate_total_expenses(self):
        """Add up all expenses"""
        return sum(self.expenses.values())
    
    def calculate_savings(self):
        """Calculate savings (income - expenses)"""
        return self.total_income - self.calculate_total_expenses()
    
    def get_expense_breakdown(self):
        """Show what percentage each expense is of total income"""
        breakdown = {}
        for category, amount in self.expenses.items():
            if self.total_income > 0:
                percentage = (amount / self.total_income) * 100
            else:
                percentage = 0
            breakdown[category] = {
                'amount': amount,
                'percentage': round(percentage, 2)
            }
        return breakdown
    
    def to_dict(self):
        """Convert user data to dictionary for CSV export"""
        user_dict = {
            'age': self.age,
            'gender': self.gender,
            'total_income': self.total_income,
            'total_expenses': self.calculate_total_expenses(),
            'savings': self.calculate_savings()
        }
        
        # Add individual expense categories
        for category, amount in self.expenses.items():
            user_dict[f'expense_{category}'] = amount
        
        return user_dict
    
    def display_summary(self):
        """Print a nice summary of the user"""
        print(f"\n=== USER SUMMARY ===")
        print(f"Age: {self.age}")
        print(f"Gender: {self.gender}")
        print(f"Income: ${self.total_income:,.2f}")
        print(f"Total Expenses: ${self.calculate_total_expenses():,.2f}")
        print(f"Savings: ${self.calculate_savings():,.2f}")
        
        print("\nExpense Breakdown:")
        breakdown = self.get_expense_breakdown()
        for category, data in breakdown.items():
            print(f"  {category}: ${data['amount']:,.2f} ({data['percentage']}%)")

# Let's test our class
if __name__ == "__main__":
    # Create a test user
    test_expenses = {
        'utilities': 150.0,
        'entertainment': 75.0,
        'school_fees': 200.0,
        'shopping': 100.0,
        'healthcare': 50.0
    }
    
    test_user = User(25, "Female", 3000.0, test_expenses)
    test_user.display_summary()
    
    # Test the dictionary conversion
    print(f"\nAs dictionary: {test_user.to_dict()}")