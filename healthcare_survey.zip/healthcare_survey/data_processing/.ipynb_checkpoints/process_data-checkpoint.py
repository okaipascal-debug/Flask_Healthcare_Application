import pandas as pd
import os
import sys

# Add the parent directory to Python path so we can import our class
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data_processing.user_class import User

class DataProcessor:
    """Process data from our application and export to CSV"""
    
    def __init__(self):
        # For now, we'll create some sample data
        # Later we'll connect to MongoDB
        self.sample_data = [
            {
                'age': 25,
                'gender': 'Female',
                'total_income': 3000.0,
                'expenses': {
                    'utilities': 150.0,
                    'entertainment': 75.0,
                    'school_fees': 200.0,
                    'shopping': 100.0,
                    'healthcare': 50.0
                }
            },
            {
                'age': 35,
                'gender': 'Male', 
                'total_income': 4500.0,
                'expenses': {
                    'utilities': 200.0,
                    'entertainment': 150.0,
                    'school_fees': 300.0,
                    'shopping': 200.0,
                    'healthcare': 100.0
                }
            },
            {
                'age': 42,
                'gender': 'Female',
                'total_income': 5200.0,
                'expenses': {
                    'utilities': 180.0,
                    'entertainment': 120.0,
                    'school_fees': 400.0,
                    'shopping': 250.0,
                    'healthcare': 150.0
                }
            }
        ]
    
    def create_user_objects(self):
        """Create User objects from our data"""
        user_objects = []
        
        for data in self.sample_data:
            user = User(
                age=data['age'],
                gender=data['gender'],
                total_income=data['total_income'],
                expenses=data['expenses']
            )
            user_objects.append(user)
        
        return user_objects
    
    def export_to_csv(self, filename='data/survey_data.csv'):
        """Export data to CSV file"""
        
        # Create User objects
        users = self.create_user_objects()
        
        # Convert to list of dictionaries
        user_dicts = []
        for user in users:
            user_dicts.append(user.to_dict())
        
        # Create DataFrame
        df = pd.DataFrame(user_dicts)
        
        # Create data directory if it doesn't exist
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        
        # Export to CSV
        df.to_csv(filename, index=False)
        print(f"✅ Data exported to {filename}")
        print(f"📊 Total records: {len(users)}")
        
        # Show what we exported
        print("\n📋 First few rows of data:")
        print(df.head())
        
        return df

# Run the processor
if __name__ == "__main__":
    processor = DataProcessor()
    df = processor.export_to_csv()
